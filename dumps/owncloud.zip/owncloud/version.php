<?php 
$OC_Version = array(8,1,1,3);
$OC_VersionString = '8.1.1';
$OC_Edition = '';
$OC_Channel = 'stable';
$OC_Build = '2015-08-08T00:57:40+00:00 ca66a705ec59cce1ac60c2fb92ec543e296c23f9';
